import{RouterModule, Routes} from '@angular/router';
import{NgModule} from '@angular/core';
import{ProductFormComponent} from '../mycomponent/product-form.component';
import{SignupFormComponent} from '../mycomponent/signup-form.component';

const appRoutes: Routes=[{
                            path:'productform',
                            component: ProductFormComponent
                            },
                            {
                            path: 'signupform',
                            component: SignupFormComponent
                            }
                        ];

@NgModule({
    imports: [RouterModule.forRoot(appRoutes)],
    exports: [RouterModule]
})
export class AppRoutingModule
{

}