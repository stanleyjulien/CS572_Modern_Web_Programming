import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{ProductFormComponent} from './mycomponent/product-form.component';
import{FormsModule, ReactiveFormsModule, FormGroup, ControlContainer } from '@angular/forms';
import{SignupFormComponent} from './mycomponent/signup-form.component';
import{AppRoutingModule} from './routing/app-routing.module';


import { AppComponent } from './app.component';


@NgModule({
  declarations: [
    AppComponent,
    ProductFormComponent,
    SignupFormComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
