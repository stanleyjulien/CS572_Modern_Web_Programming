import{Component} from '@angular/core';
import{FormsModule, ReactiveFormsModule, FormGroup, FormControl, ControlContainer} from '@angular/forms'

@Component(
    {
        selector: 'app-signup-form',
        template: `
                    <form [formGroup]="signupForm" (ngSubmit)="signup()">
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input formControlName="username" type="text" id="username" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input formControlName="password" type="text" id="password" class="form-control">
                        </div>
                        <button class="btn btn-primary" type="submit">Sign Up</button>
                    </form>
                  `,
        styles: []
    }
)
export class SignupFormComponent
{
    signupForm = new FormGroup({
            username: new FormControl(),
            password: new FormControl()
    });

    signup() {
        console.log(this.signupForm.value);
    }
}