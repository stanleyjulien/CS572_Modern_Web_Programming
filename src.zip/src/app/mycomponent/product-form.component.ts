import{Component} from '@angular/core';

@Component(
    {
        selector: 'product-form',
        template: `
                    <form>
                        <div class="form-group">
                            <label for="product_name"> Product name </label>

                            <input required ngModel name="product_name" #productName="ngModel"  (change)="log(productName)" 
                            id="product_name" type="text" class="form-control" >
                            <div class="alert alert-danger" *ngIf="productName.touched && !productName.valid"> 
                                Product name is required 
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="description"> Description </label>

                            <textarea ngModel name="description" id="description" cols="30" rows="10" class="form-control">
                            </textarea>
                        </div>

                        <!-- Form group -->
                        <fieldset ngModelGroup="contact">
                            <label> First Name <input type="text" name="firstname" ngModel> </label>
                            <label> Last Name <input type="text" name="lastname" ngModel> </label>
                        </fieldset>

                        <button class="btn btn-primary"> submit </button>
                    </form>

                   
                  `,
        styles: []
    }
)
export class ProductFormComponent
{
    log(model)
    {
        console.log(model);
    }
}