import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
            <h1> Welcome to {{title}} </h1>
            
            <a routerLink="/productform"> Product Form </a> <br />
            <a routerLink="/signupform"> Sigup Form </a>
            <router-outlet></router-outlet>

            <!-- <product-form></product-form>
            <br />
            <app-signup-form></app-signup-form>
            -->

  `,
  styles: []
})
export class AppComponent {
  title = 'App Form';
}
