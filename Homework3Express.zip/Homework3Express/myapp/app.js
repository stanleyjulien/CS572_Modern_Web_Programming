var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var fetch = require('node-fetch');

var index = require('./routes/index');
var users = require('./routes/users');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');
app.set('port', process.env.PORT || 3000);
app.set('env', 'development');
//app.set('views',path.join(__dirname,'templates'));
//app.set('view engine','jade');
app.get('/',function(request,response)
			{
				response.render('index',{title:'MWA'});
			});
app.get('/users',function(request,response)
			{
				//const url = "http://jsonplaceholder.typicode.com/users";
				//request.get(url, (value) => {console.log(value);})
				var data ;
				/*fetch('http://jsonplaceholder.typicode.com/users')
			    .then(function(res) { return res.json(); })
			    .then(function(json) { console.log(json); });
			    */

			    fetch('http://jsonplaceholder.typicode.com/users')
			    .then(function(res) { return res.json(); })
			    .then(function(json) { 
			    						//json return an array of (json data), we must find a way to loop on it and to display values
			    						//console.log(json); 
			    						data = json;
			    						response.render('index.jade', {title: json[0].id, id: json[0].id, name: json[0].name, username: json[0].username,
			    									email: json[0].email, address: json[0].address});
			    						/*for(const i=0; i<json.length; i++)
			    						{
			    							console.log(json[i].id);
			    						}*/
			    					});
				
				//response.render('index.jade',{title:'MWA'});
				console.log("Data: " +data)
				//response.render('index.jade', {data});
			});
const port = app.get('port');
console.log(app.get('env'));


// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', index);
app.use('/users', users);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
app.listen(3000, ()=>
				{
					console.log('Listening on port 3000');
				}
		  );
